sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"

], function (Controller, MessageToast) {
	"use strict";

	return Controller.extend("com.incture.cherrywork.GuestLogin.controller.View1", {

		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "RouteView1") {
					//
				}
			});
		},
		onPageNav: function () {

			var name = sap.ui.core.Fragment.byId("myFrag", "uName").getValue();
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			var pass = sap.ui.core.Fragment.byId("myFrag", "passWord").getValue();
			if (pass === "") {
				MessageToast.show("password can not be empty");
				return false;
			}

			var oDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDetails, "oDetails");
			var url = "/AdminDetails/uri/LoginGet";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData = {};

			aData.name = name;
			aData.password = pass;

			oDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);

			oDetails.attachRequestCompleted(function (oEvent) {
				console.log(oEvent);
				//	console.log(aData);
				//	alert("yess");
				//	alert(oDetails.getData().responseMessage.status);
				//var check = oEvent.mParameters.errorobject.responseText;
				//	var check = oEvent.getParameters().responseRaw;
				var check = oEvent.mParameters.errorobject.responseText;
				console.log(check);
				//	check = check.status;
				//console.log(oEvent);
				//	: "requestCompleted"
				if (check == "success") {
					this.oRouter.navTo("secondpage");
				} else {
					MessageToast.show("Invalid user name password");
				}
			}.bind(this));

			oDetails.attachRequestFailed(function (oEvent) {
			
				//	that.getView().byId("").setVisible(false);
				//	alert("faliure");

			});
				this.oRouter.navTo("secondpage");

		},

		onPress: function () {

			var oFragmentName = "com.incture.cherrywork.GuestLogin.fragment.login";
			var ofragId = "myFrag";
			if (!this.myDialogFragment) {
				this.myDialogFragment = this.createFragment(ofragId, oFragmentName);
				this.getView().addDependent(this.myDialogFragment);
			}
			this.myDialogFragment.open();

		},

		onCheckout: function () {
			var FragmentName = "com.incture.cherrywork.GuestLogin.fragment.checkout";
			var fragId = "checkOut";
			if (!this.DialogFragment) {
				this.DialogFragment = this.createFragment(fragId, FragmentName);
				this.getView().addDependent(this.DialogFragment);
			}
			this.DialogFragment.open();
		},
		createFragment: function (sFragmentID, sFragmentName) {
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		},
		onCheckSubmit: function () {

			var oPhoneNumber = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oPhoneNumber, "oPhoneNumber");
			var url = "/AdminDetails/uri/checkout";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var phoneNumber = sap.ui.core.Fragment.byId("checkOut", "phoneNumber").getValue();
			console.log(phoneNumber);
			var aData = {};

			aData.phoneNumber = phoneNumber;

			oPhoneNumber.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			oPhoneNumber.attachRequestCompleted(function (oEvent) {
				var check = oEvent.mParameters.errorobject.responseText;
				console.log(check);
				if (check === "success") {
					MessageToast.show(" Checked out");
				//	this.DialogFragment.close();
				} else {
					MessageToast.show("Invalid Phone Number");
				}

			});

			oPhoneNumber.attachRequestFailed(function (oEvent) {
				//	that.busy.close();
				//	that.getView().byId("idPageNumberDiv").setVisible(false);
				//	toastMessage(taskInboxModel.getData().responseMessage.status);

			});
		}
	});

});