sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"

], function (Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("com.incture.cherrywork.GuestLogin.controller.Details", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.incture.cherrywork.GuestLogin.view.Details
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.incture.cherrywork.GuestLogin.view.Details
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.incture.cherrywork.GuestLogin.view.Details
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.incture.cherrywork.GuestLogin.view.Details
		 */
		//	onExit: function() {
		//
		//}
		onSubmit: function () {
			var name = this.getView().byId("name").getValue();
			this.reg1 = /([0-9])/;
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			if (!isNaN(name)) {
				MessageToast.show("Name can not have a number");
				return false;
			}
			if (this.reg1.test(name)) {
				MessageToast.show("Alphanumeric Name is not allowed");
				return false;
			}

			var y = this.getView().byId("Email").getValue();
			if (y === "") {
				MessageToast.show("Email cant be empty");
				return false;
			} else if (/^[a-zA-Z0-9]+$/.test(y)) {
				MessageToast.show("Invalid Email Id");
				return false;
			} else if (/^([a-zA-Z0-9@]{2,5})$/.test(y)) {
				MessageToast.show("Invalid Email Id");
				return false;
			} else if (/^([a-zA-Z0-9_\@]+)$/.test(y)) {
				MessageToast.show("Invalid Email Id");
				return false;
			}

			var reg =
				/^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\-\.]+)@{[a-zA-Z0-9_\-\.]+0\.([a-zA-Z]{2,5}){1,25})+)*$/;
			if (reg.test(y) === false) {
				MessageToast.show("Email should have 2 char after . symbol");
				return false;
			}

			var b = this.getView().byId("number").getValue();
			if (b === "") {
				MessageToast.show("phone number cann't be empty");
				return false;
			}
			var reg1 = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (reg1.test(b) === false) {
				MessageToast.show("phone number should have only 10 digits");
				return false;
			}

			var purpose = this.getView().byId("purpose").getSelectedItem().getText();
			var HostName = this.getView().byId("HostName").getSelectedItem().getText();
			//	var name = this.getView().byId("name").getValue();
			//	var that = this;

			var oDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDetails, "oDetails");
			var url = "/AdminDetails/uri/VisitorPost";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData = {};
			aData.email = y;
			aData.hostName = HostName;
			aData.name = name;
			aData.phoneNumber = b;
			aData.purpose = purpose;
			aData.checkin = "1:676";
			aData.checkout = "1:76767";

			oDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			oDetails.attachRequestCompleted(function (oEvent) {
				//	console.log(aData);
				//	alert("yess");

			});

			oDetails.attachRequestFailed(function (oEvent) {
				//	that.busy.close();
				//	that.getView().byId("idPageNumberDiv").setVisible(false);
				//	toastMessage(taskInboxModel.getData().responseMessage.status);
			});

			var fragmentName = "com.incture.cherrywork.GuestLogin.fragment.thankyou";
			var FragId = "thankyou";
			if (!this.DialogFragment) {
				this.DialogFragment = this.createFragment(FragId, fragmentName);
				this.getView().addDependent(this.DialogFragment);
			}
			this.DialogFragment.open();

			setTimeout(function () {
				this.DialogFragment.close();
				this.oRouter.navTo("RouteView1");
			}.bind(this), 4000);

		},

		createFragment: function (sFragmentID, sFragmentName) {
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		},

		onInit: function () {
			var oModel = new JSONModel();
			this.getView().setModel(oModel, "hModel");
			oModel.loadData("/AdminDetails/uri/HostnameGet", null, true);
			oModel.attachRequestCompleted(function (Event) {

				var b = Event.getSource().getData();

				console.log(b);
				this.getView().getModel("hModel").setProperty("/getHostname", b);

			}.bind(this));
			oModel.attachRequestFailed(function (oEvent) {});

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "thirdpage") {
					//
				}

			});

			//	set explored app 's demo model on this sample
			//	var oModel1 = new JSONModel(oModel);
			//	this.getView().setModel(oModel1);

			//	this.getView().setModel(oModel);

		},

		LivechangeName: function (oEvent) {
			var newName = oEvent.getParameter("value");
			this.byId("getname").setText(newName);
		},

		LivechangeEmail: function (Event) {
			var newEmail = Event.getParameter("value");
			this.byId("getEmail").setText(newEmail);
		}

	});

});