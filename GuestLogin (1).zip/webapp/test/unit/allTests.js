sap.ui.define([
	"com/incture/cherrywork/GuestLogin/test/unit/controller/View1.controller"
], function () {
	"use strict";
});