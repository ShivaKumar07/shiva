/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"com/incture/cherrywork/GuestLogin/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/incture/cherrywork/GuestLogin/test/integration/pages/View1",
	"com/incture/cherrywork/GuestLogin/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.incture.cherrywork.GuestLogin.view.",
		autoWait: true
	});
});