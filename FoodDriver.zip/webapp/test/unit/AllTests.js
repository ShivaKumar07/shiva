sap.ui.define([
	"com/incture/cherrywork/FoodDriver/test/unit/controller/DriverView1.controller"
], function () {
	"use strict";
});