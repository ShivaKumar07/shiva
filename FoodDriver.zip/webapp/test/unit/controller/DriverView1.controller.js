/*global QUnit*/

sap.ui.define([
	"com/incture/cherrywork/FoodDriver/controller/DriverView1.controller"
], function (oController) {
	"use strict";

	QUnit.module("DriverView1 Controller");

	QUnit.test("I should test the DriverView1 controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});