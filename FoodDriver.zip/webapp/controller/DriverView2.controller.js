sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";
		
		
	var driveremail;
	return Controller.extend("com.incture.cherrywork.FoodDriver.controller.DriverView2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.incture.cherrywork.FoodDriver.view.DriverView2
		 */
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "DriverView2") {
					//
				}
			});

			var data = sap.ui.getCore().getModel("data");
			this.getView().setModel(data);
			console.log(data);
			var driverData1 = data.getData();
			console.log(driverData1);
			driveremail = driverData1.email;
			console.log(driveremail);
			
			var oModel1 = sap.ui.getCore().getModel("oDriverlogin3");
			this.getView().setModel(oModel1);
			console.log(oModel1);
			var driverData = oModel1.getData();
			console.log(driverData);
			

 		var oModel = new JSONModel();
			this.getView().setModel(oModel, "oModel");
			this.getView().getModel("oModel").setProperty("/driverData", driverData);
			console.log(oModel);
			/*var oModel = new JSONModel({
				modelData: driverData
			});
			this.getView().setModel(oModel);
			console.log(oModel);*/
		},
		onLogout: function () {
			var oDetails2 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDetails2, "oDetails2");
			var url2 = "/FoodApp/Food/Drivernamedelete";
			var oHeader2 = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData2 = {};
			aData2.email = driveremail;

			console.log(aData2);
			oDetails2.loadData(url2, JSON.stringify(aData2), true, "POST", false, false, oHeader2);
			oDetails2.attachRequestCompleted(function (oEvent) {

			});

			this.oRouter.navTo("RouteDriverView1");
		},
		onDeliverd: function (event) {
			var oModel2 = sap.ui.getCore().getModel("oDriverlogin4");
			this.getView().setModel(oModel2);
			console.log(oModel2);

			var rest = event.getSource().getBindingContext("oModel").getObject();
			console.log(rest);
			driveremail = rest.driverEmail;
			var orderid = rest.orderId;
			console.log(orderid);
			/*	var oDetails = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oDetails, "oDetails");
				var url = "/FoodApp/Food/logout";
				var oHeader = {
					"Content-Type": "application/json;charset=utf-8"
				};
				var aData = {};

				aData.ordeInfoId = 6;

				oDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);

				oDetails.attachRequestCompleted(function (oEvent) {

				}.bind(this));*/

			var oDetails1 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDetails1, "oDetails1");
			var url1 = "/FoodApp/Food/logout";
			var oHeader1 = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData1 = {};
			aData1.orderId = orderid;
			aData1.driverEmail = driveremail;
			console.log(aData1);
			oDetails1.loadData(url1, JSON.stringify(aData1), true, "POST", false, false, oHeader1);
			oDetails1.attachRequestCompleted(function (oEvent) {

			}.bind(this));

			var oDetails2 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDetails1, "oDetails1");
			var url2 = "/FoodApp/Food/Statusupdate";
			var oHeader2 = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData2 = {};
			aData2.orderId = orderid;
			aData2.driverEmail = driveremail;
			console.log(aData2);
			oDetails2.loadData(url2, JSON.stringify(aData2), true, "POST", false, false, oHeader2);
			oDetails2.attachRequestCompleted(function (oEvent) {

			}.bind(this));

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.incture.cherrywork.FoodDriver.view.DriverView2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.incture.cherrywork.FoodDriver.view.DriverView2
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.incture.cherrywork.FoodDriver.view.DriverView2
		 */
		//	onExit: function() {
		//
		//	}

	});

});