sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";

	var a = {};
	var c;
	var d;
	var DriverEmail;
	return Controller.extend("com.incture.cherrywork.FoodDriver.controller.DriverView1", {
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "RouteDriverView1") {
					//
				}
			});

		},
		onRegister: function () {
			var DFragmentName = "com.incture.cherrywork.FoodDriver.fragment.DriverSIgnup";
			var DfragId = "DriverSignup";
			if (!this.DDialogFragment) {
				this.DDialogFragment = this.createFragment(DfragId, DFragmentName);
				this.getView().addDependent(this.DDialogFragment);
			}
			this.DDialogFragment.open();

		},
		createFragment: function (sFragmentID, sFragmentName) {
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		},

		onDriverLogin: function () {
			var name = this.getView().byId("DriverName").getValue();
			DriverEmail = name;

			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			var pass = this.getView().byId("DriverpassWord").getValue();
			if (pass === "") {
				MessageToast.show("password can not be empty");
				return false;
			}

			var Epass = window.btoa(pass);

			var oDriverlogin4 = new sap.ui.model.json.JSONModel();
			sap.ui.getCore().setModel(oDriverlogin4, "oDriverlogin4");
			sap.ui.getCore().getModel("oDriverlogin4").setData(name, "/name");
			console.log(oDriverlogin4);

			var data = new sap.ui.model.json.JSONModel();
			sap.ui.getCore().setModel(data, "data");
			data.loadData("/FoodApp/Food/Driverdetailsget?email=" + name, null, true);
			data.attachRequestCompleted(function (oEvent) {

				var b = oEvent.getSource().getData();
				console.log(b);
				c = b.name;
				console.log(c);
				d = b.email;
				console.log(d);

				sap.ui.getCore().getModel("data").setData(b, "/getDriver");
				console.log(data);

			}.bind(this));
			data.attachRequestFailed(function (oEvent) {

			});

			var oDriverlogin3 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDriverlogin3, "oDriverlogin3");
			var url1 = "/FoodApp/Food/Assigndriverdetailsget";
			var oHeader1 = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData1 = {};
			aData1.driverEmail = name;

			oDriverlogin3.loadData(url1, JSON.stringify(aData1), true, "POST", false, false, oHeader1);
			oDriverlogin3.attachRequestCompleted(function (oEvent1) {
				var x = oEvent1.getSource();
				sap.ui.getCore().setModel(oDriverlogin3, "oDriverlogin3");

				console.log(x);
				console.log(oDriverlogin3);

			});
			oDriverlogin3.attachRequestFailed(function (oEvent1) {

			});

			var oDriverlogin2 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDriverlogin2, "oDriverlogin2");
			var url2 = "/FoodApp/Food/Drivernamepost";
			var oHeader2 = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var oDriver = {};
			oDriver.name = c;
			oDriver.email = d;

			console.log(oDriver);
			/*	oDriver.name = a.name;
				oDriver.email = a.email;*/

			oDriverlogin2.loadData(url2, JSON.stringify(oDriver), true, "POST", false, false, oHeader2);
			oDriverlogin2.attachRequestCompleted(function (Event) {

			});
			oDriverlogin2.attachRequestFailed(function (Event) {

			});

			var oDriverlogin = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDriverlogin, "oCustomerlogin");
			var url = "/FoodApp/Food/DloginGet";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData = {};

			aData.email = name;
			aData.password = Epass;
			oDriverlogin.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			oDriverlogin.attachRequestCompleted(function (oEvent) {
				var check = oEvent.mParameters.errorobject.responseText;
				console.log(check);
				//console.log(oEvent);
				if (check === "success") {
					this.oRouter.navTo("DriverView2");
				} else {
					MessageToast.show("Invalid user name or password");
					//	this.oRouter.navTo("CustomerView2a");
				}
			}.bind(this));
			oDriverlogin.attachRequestFailed(function (oEvent) {

			});

		},

		onDriverSubmit: function () {
			var name = sap.ui.core.Fragment.byId("DriverSignup", "Drivername").getValue();
			this.reg1 = /([0-9])/;
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			if (!isNaN(name)) {
				MessageToast.show("Name can not have a number");
				return false;
			}
			if (this.reg1.test(name)) {
				MessageToast.show("Alphanumeric Name is not allowed");
				return false;
			}
			var userphoneNumber = sap.ui.core.Fragment.byId("DriverSignup", "DriverNumber").getValue();
			if (userphoneNumber === "") {
				MessageToast.show("phone number cann't be empty");
				return false;
			}
			var reg1 = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (reg1.test(userphoneNumber) === false) {
				MessageToast.show("phone number should have only 10 digits");
				return false;
			}

			var userEmail = sap.ui.core.Fragment.byId("DriverSignup", "driverEmail").getValue();
			if (userEmail === "") {
				MessageToast.show("Email cant be empty");
				return false;
			} else if (/^[a-zA-Z0-9]+$/.test(userEmail)) {
				MessageToast.show("Invalid Email Id");
				return false;
			} else if (/^([a-zA-Z0-9@]{2,5})$/.test(userEmail)) {
				MessageToast.show("Invalid Email Id");
				return false;
			} else if (/^([a-zA-Z0-9_\@]+)$/.test(userEmail)) {
				MessageToast.show("Invalid Email Id");
				return false;
			}
			var reg =
				/^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\-\.]+)@{[a-zA-Z0-9_\-\.]+0\.([a-zA-Z]{2,5}){1,25})+)*$/;
			if (reg.test(userEmail) === false) {
				MessageToast.show("Email should have 2 char after . symbol");
				return false;
			}

			var address = sap.ui.core.Fragment.byId("DriverSignup", "DriverAddress").getValue();
			if (address === "") {
				MessageToast.show("Address can not be empty");
				return false;
			}
			var dlNumber = sap.ui.core.Fragment.byId("DriverSignup", "DLnumber").getValue();
			if (dlNumber === "") {
				MessageToast.show("Please enter the DL number");
				return false;
			}
			var re = /^([A-Z]{2})(\d{2})(\d{4})(\d{7})$/;
			if (re.test(dlNumber) === false) {
				MessageToast.show("Please enter the valid DL number");
				return false;
			}
			var Userpassword = sap.ui.core.Fragment.byId("DriverSignup", "DriverPass").getValue();
			if (Userpassword === "") {
				MessageToast.show("Create a new password");
				return false;
			}
			var Usercpassword = sap.ui.core.Fragment.byId("DriverSignup", "DriverCPass").getValue();
			if (Usercpassword === "") {
				MessageToast.show("Please enter the password again");
				return false;
			}
			if (Usercpassword !== Userpassword) {
				MessageToast.show("password doesnot match");
				return false;
			}

			var dDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(dDetails, "dDetails");
			var url = "/FoodApp/Food/Driverpost";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};

			var Userpassword1 = window.btoa(Userpassword);

			var dData = {};
			dData.phone = userphoneNumber;
			dData.name = name;
			dData.email = userEmail;
			dData.address = address;
			dData.password = Userpassword1;
			dData.dlNumber = dlNumber;

			dDetails.loadData(url, JSON.stringify(dData), true, "POST", false, false, oHeader);
			dDetails.attachRequestCompleted(function (oEvent) {

			});
			dDetails.attachRequestFailed(function (oEvent) {

			});
			this.DDialogFragment.close();
			//	this.oRouter.navTo("RouteDriverView1");
		}

	});
});