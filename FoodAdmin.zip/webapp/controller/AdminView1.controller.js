sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("com.incture.cherrywork.FoodAdmin.controller.AdminView1", {
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "RouteView1") {
					//
				}
			});

		},

		onAdminLogin: function () {
			var name = this.getView().byId("AName").getValue();
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			var pass = this.getView().byId("ApassWord").getValue();
			if (pass === "") {
				MessageToast.show("password can not be empty");
				return false;
			}
			
			var Epass = window.btoa(pass);
			console.log(Epass);
			
			var oDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDetails, "oDetails");
			var url = "/FoodApp/Food/AloginGet";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData = {};

			aData.username = name;
			aData.password = Epass;

			oDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);

			oDetails.attachRequestCompleted(function (oEvent) {
				var check = oEvent.mParameters.errorobject.responseText;
				console.log(check);
				//	check = check.status;
				//console.log(oEvent);

				if (check === "success") {
					this.oRouter.navTo("AdminView2");

				} else {
					MessageToast.show("Invalid user name or password");
				}
			}.bind(this));

			oDetails.attachRequestFailed(function (oEvent) {

				//	alert("faliure");

			});

		}
	});
});