sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"

], function (Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("com.incture.cherrywork.FoodAdmin.controller.AdminView4addrest", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView4addrest
		 */
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "AdminView4addrest") {
					//
				}
			});

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView4addrest
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView4addrest
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView4addrest
		 */
		//	onExit: function() {
		//
		//	}
		Addbutton: function () {

			var name = this.getView().byId("name").getValue();
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}

			var number = this.getView().byId("number").getValue();
			if (number === "") {
				MessageToast.show("phone number cann't be empty");
				return false;
			}
			var reg1 = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (reg1.test(number) === false) {
				MessageToast.show("phone number should have only 10 digits");
				return false;
			}
			var RestAddress = this.getView().byId("RestAddress").getValue();
			if (RestAddress === "") {
				MessageToast.show("Address can not be empty");
				return false;
			}

			var Restphoto = this.getView().byId("Restphoto").getValue();

			var oRestDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRestDetails, "oRestDetails");
			var url = "/FoodApp/Food/Restpost";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData = {};

			var items1 = this.getView().byId("items1").getValue();
			var price1 = this.getView().byId("price1").getValue();

			var items2 = this.getView().byId("items2").getValue();
			var price2 = this.getView().byId("price2").getValue();

			var items3 = this.getView().byId("items3").getValue();
			var price3 = this.getView().byId("price3").getValue();

			var items4 = this.getView().byId("items4").getValue();
			var price4 = this.getView().byId("price4").getValue();

			var aItems1 = {};
			var aItems2 = {};
			var aItems3 = {};
			var aItems4 = {};

			aItems1.itemName = items1;
			aItems1.itemPrice = price1;
			aItems2.itemName = items2;
			aItems2.itemPrice = price2;
			aItems3.itemName = items3;
			aItems3.itemPrice = price3;
			aItems4.itemName = items4;
			aItems4.itemPrice = price4;

			var allItems = [];

			var aItems = [aItems1, aItems2, aItems3, aItems4];

			for (var i = 0; i < aItems.length; i++) {
				if (aItems[i].itemName !== "" && aItems[i].itemPrice !== "") {
					allItems.push(aItems[i]);
				}
			}
			//	console.log(allItems);

			aData.item = allItems;
			aData.restPhoto = Restphoto;
			aData.restAddress = RestAddress;
			aData.restName = name;
			aData.restPhone = number;

			oRestDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			oRestDetails.attachRequestCompleted(function (oEvent) {
				MessageToast.show("Resturant has been Added");

			});
			oRestDetails.attachRequestFailed(function (oEvent) {

			});
			this.oRouter.navTo("AdminView2");
		},
		onHomepress: function () {

			this.oRouter.navTo("AdminView2");
		}

	});

});