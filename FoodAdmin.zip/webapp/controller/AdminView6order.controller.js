sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";

	var driveremail;

	return Controller.extend("com.incture.cherrywork.FoodAdmin.controller.AdminView6order", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView6order
		 */
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "AdminView3rest") {
					//
				}
			});

			var orderDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(orderDetails, "orderDetails");
			orderDetails.loadData("/FoodApp/Food/Orderget", null, true);
			orderDetails.attachRequestCompleted(function (oEvent) {

				var Orderdata = oEvent.getSource().getData();
				console.log(Orderdata);
				/*	var oOrderdata = new JSONModel({
						modelData: Orderdata
					});
					this.getView().setModel(oOrderdata);*/

				this.getView().getModel("orderDetails").setProperty("/Orderdata", Orderdata);
				console.log(orderDetails);

			}.bind(this));
			orderDetails.attachRequestFailed(function (oEvent) {

			});

			var orderDetails1 = new sap.ui.model.json.JSONModel();
			this.getView().setModel(orderDetails1, "orderDetails1");
			orderDetails1.loadData("/FoodApp/Food/Drivernameget", null, true);
			orderDetails1.attachRequestCompleted(function (oEvent) {

				var oDriver = oEvent.getSource().getData();
				console.log(oDriver);
				/*	var oOrderdata = new JSONModel({
						modelData: Orderdata
					});
					this.getView().setModel(oOrderdata);*/

				this.getView().getModel("orderDetails1").setProperty("/oDriver", oDriver);
				console.log(orderDetails1);

			}.bind(this));
			orderDetails1.attachRequestFailed(function (oEvent) {

			});

		},

		onDriverSelect: function (event) {

			/*	var rest = event.getSource().getBindingContext("orderDetails1");
				console.log(rest);*/

			console.log(event);
			var x = event.getParameters();
			console.log(x);

			var b = x.value;
			driveremail = b;

		},
		onAssignDriver: function (event) {
			var rest = event.getSource().getBindingContext("orderDetails").getObject();
			console.log(rest);

			var a = rest.orderId;
			console.log(a);
			console.log(driveremail);

			var oAssign = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAssign, "oAssign");
			var url1 = "/FoodApp/Food/Updatedriveremail";
			var oHeader1 = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData1 = {};
			aData1.orderId = a;
			aData1.driverEmail = driveremail;

			oAssign.loadData(url1, JSON.stringify(aData1), true, "POST", false, false, oHeader1);
			oAssign.attachRequestCompleted(function (oEvent) {

			});
			oAssign.attachRequestFailed(function (oEvent) {

			});

			var oRestDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRestDetails, "oRestDetails");
			var url = "/FoodApp/Food/Assigndriver";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			var aData = {};
			aData.orderId = a;
			aData.driverEmail = driveremail;

			oRestDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			oRestDetails.attachRequestCompleted(function (oEvent) {

			});
			oRestDetails.attachRequestFailed(function (oEvent) {

			});

			MessageToast.show("Order has been assigned");

		},

		onHomepress: function () {
			this.oRouter.navTo("AdminView2");
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView6order
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView6order
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.incture.cherrywork.FoodAdmin.view.AdminView6order
		 */
		//	onExit: function() {
		//
		//	}

	});

});