sap.ui.define([
	"com/incture/cherrywork/FoodAdmin/test/unit/controller/AdminView1.controller"
], function () {
	"use strict";
});