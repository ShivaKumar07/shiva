/*global QUnit*/

sap.ui.define([
	"com/incture/cherrywork/FoodAdmin/controller/AdminView1.controller"
], function (oController) {
	"use strict";

	QUnit.module("AdminView1 Controller");

	QUnit.test("I should test the AdminView1 controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});