sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";
	var a = {};
	return Controller.extend("com.incture.cherrywork.foodApp.controller.View1", {
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "RouteView1") {
					//
				}
			});

		},

		onLogin: function () {
			var FragmentName = "com.incture.cherrywork.foodApp.fragment.customerLogin";
			var fragId = "customerLogin";
			if (!this.DialogFragment) {
				this.DialogFragment = this.createFragment(fragId, FragmentName);
				this.getView().addDependent(this.DialogFragment);
			}
			this.DialogFragment.open();

		},
		createFragment: function (sFragmentID, sFragmentName) {
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		},
		onSignup: function () {
			var sFragmentName = "com.incture.cherrywork.foodApp.fragment.customerSignup";
			var sfragId = "customerSignup";
			if (!this.sDialogFragment) {
				this.sDialogFragment = this.createFragment(sfragId, sFragmentName);
				this.getView().addDependent(this.sDialogFragment);
			}
			this.sDialogFragment.open();
		},

		onCustomerLogin: function () {

			var name = sap.ui.core.Fragment.byId("customerLogin", "uName").getValue();
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			var pass = sap.ui.core.Fragment.byId("customerLogin", "passWord").getValue();
			if (pass === "") {
				MessageToast.show("password can not be empty");
				return false;
			}

			var oCdata = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCdata, "oCdata");
			oCdata.loadData("/FoodApp/Food/Customer?email=" + name, null, true);
			oCdata.attachRequestCompleted(function (oEvent) {

				a = oEvent.getSource().getData();
				console.log(a);
				sap.ui.getCore().setModel(oCdata, "oCdata");
				console.log(oCdata);
			}.bind(this));
			oCdata.attachRequestFailed(function (oEvent) {});

			var oCustomerlogin = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCustomerlogin, "oCustomerlogin");
			var url = "/FoodApp/Food/CloginGet";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};

			var Epass = window.btoa(pass);
			//	var dec = window.atob(enc);

			var aData = {};

			aData.email = name;
			aData.password = Epass;

			oCustomerlogin.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);

			//	this.oRouter.navTo("CustomerView2a");

			oCustomerlogin.attachRequestCompleted(function (oEvent) {
				//	console.log(oEvent);
				var check = oEvent.mParameters.errorobject.responseText;
				console.log(check);
				if (check === "success") {
					this.oRouter.navTo("CustomerView2a");

				} else {
					MessageToast.show("Invalid user name or password");
					//	this.oRouter.navTo("CustomerView2a");
				}
			}.bind(this));

			oCustomerlogin.attachRequestFailed(function (oEvent) {

				//	alert("faliure");

			});

		},
		onForget: function () {
			var sfFragmentName = "com.incture.cherrywork.foodApp.fragment.customerpassword";
			var sFfragId = "customerforgrtpass";
			if (!this.sFDialogFragment) {
				this.sFDialogFragment = this.createFragment(sFfragId, sfFragmentName);
				this.getView().addDependent(this.sFDialogFragment);
			}
			this.sFDialogFragment.open();

		},

		onForgetPassword: function () {
			var Email = sap.ui.core.Fragment.byId("customerforgrtpass", "Email").getValue();
			if (Email === "") {
				MessageToast.show("Email can not be empty");
				return false;
			}
			var newpassword = sap.ui.core.Fragment.byId("customerforgrtpass", "newpassword").getValue();
			if (newpassword === "") {
				MessageToast.show("Password can not be empty");
				return false;
			}
			var newconfirmpassword = sap.ui.core.Fragment.byId("customerforgrtpass", "newconfirmpassword").getValue();
			if (newconfirmpassword === "") {
				MessageToast.show("Enter the Password again.");
				return false;
			}
			if (newpassword !== newconfirmpassword) {
				MessageToast.show("Incorrect Password");
				return false;
			}
			var Epass = window.btoa(newpassword);

			var oCustomerlogin = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oCustomerlogin, "oCustomerlogin");
			var url = "/FoodApp/Food/Forgetpswd";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};

			var aData = {};
			aData.email = Email;
			aData.password = Epass;
			oCustomerlogin.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			//	this.oRouter.navTo("CustomerView2a");
			oCustomerlogin.attachRequestCompleted(function (oEvent) {
				//
			});

			oCustomerlogin.attachRequestFailed(function (oEvent) {
				//	alert("faliure");
			});
			this.sFDialogFragment.close();
		},
		onCSubmit: function () {
			var name = sap.ui.core.Fragment.byId("customerSignup", "UserName").getValue();
			this.reg1 = /([0-9])/;
			if (name === "") {
				MessageToast.show("Name can not be empty");
				return false;
			}
			if (!isNaN(name)) {
				MessageToast.show("Name can not have a number");
				return false;
			}
			if (this.reg1.test(name)) {
				MessageToast.show("Alphanumeric Name is not allowed");
				return false;
			}
			var userphoneNumber = sap.ui.core.Fragment.byId("customerSignup", "userphoneNumber").getValue();
			if (userphoneNumber === "") {
				MessageToast.show("phone number cann't be empty");
				return false;
			}
			var reg1 = /^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
			if (reg1.test(userphoneNumber) === false) {
				MessageToast.show("phone number should have only 10 digits");
				return false;
			}

			var userEmail = sap.ui.core.Fragment.byId("customerSignup", "userEmail").getValue();
			if (userEmail === "") {
				MessageToast.show("Email cant be empty");
				return false;
			} else if (/^[a-zA-Z0-9]+$/.test(userEmail)) {
				MessageToast.show("Invalid Email Id");
				return false;
			} else if (/^([a-zA-Z0-9@]{2,5})$/.test(userEmail)) {
				MessageToast.show("Invalid Email Id");
				return false;
			} else if (/^([a-zA-Z0-9_\@]+)$/.test(userEmail)) {
				MessageToast.show("Invalid Email Id");
				return false;
			}
			var reg =
				/^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\-\.]+)@{[a-zA-Z0-9_\-\.]+0\.([a-zA-Z]{2,5}){1,25})+)*$/;
			if (reg.test(userEmail) === false) {
				MessageToast.show("Email should have 2 char after . symbol");
				return false;
			}

			var address = sap.ui.core.Fragment.byId("customerSignup", "userAddress").getValue();
			if (address === "") {
				MessageToast.show("Address can not be empty");
				return false;
			}

			var Userpassword = sap.ui.core.Fragment.byId("customerSignup", "Userpassword").getValue();
			if (Userpassword === "") {
				MessageToast.show("Create a new password");
				return false;
			}
			var Usercpassword = sap.ui.core.Fragment.byId("customerSignup", "ConfirmPassword").getValue();
			if (Usercpassword === "") {
				MessageToast.show("Please enter the password again");
				return false;
			}
			if (Usercpassword !== Userpassword) {
				MessageToast.show("password doesnot match");
				return false;
			}

			var CDetails = new sap.ui.model.json.JSONModel();
			this.getView().setModel(CDetails, "CDetails");
			var url = "/FoodApp/Food/Customerpost";
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};

			var Epass = window.btoa(Userpassword);

			var aData = {};
			aData.phone = userphoneNumber;
			aData.name = name;
			aData.email = userEmail;
			aData.address = address;
			aData.password = Epass;

			CDetails.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
			CDetails.attachRequestCompleted(function (oEvent) {

			});
			CDetails.attachRequestFailed(function (oEvent) {

			});

			var FragmentName = "com.incture.cherrywork.foodApp.fragment.customerLogin";
			var fragId = "customerLogin";
			if (!this.DialogFragment) {
				this.DialogFragment = this.createFragment(fragId, FragmentName);
				this.getView().addDependent(this.DialogFragment);
			}
			this.DialogFragment.open();

		}
	});
});