sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel, MessageToast) {
	"use strict";
	var check;

	return Controller.extend("com.incture.cherrywork.foodApp.controller.CustomerView2a", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.incture.cherrywork.foodApp.view.CustomerView2a
		 */
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "CustomerView2a") {
					//
				}
			});

			/*var oRdata = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRdata, "oRdata");

			var restdata = [{
				restName: "Blue Berry"
			}, {
				restName: "Rice Bowl"
			}];
			this.getView().getModel("oRdata").setProperty("/getResturant", restdata);*/

			var oRdata = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRdata, "oRdata");
			oRdata.loadData("/FoodApp/Food/Restget", null, true);

			oRdata.attachRequestCompleted(function (oEvent) {

				var restdata = oEvent.getSource().getData();
				console.log(restdata);

				this.getView().getModel("oRdata").setProperty("/getResturant", restdata);

			}.bind(this));
			oRdata.attachRequestFailed(function (oEvent) {});

		},
		onMenuPress: function (event) {

				var rest = event.getSource().getBindingContext("oRdata").getObject();
				var restname = rest.restName;
				var restidd = rest.restId;
				var restAddress = rest.restAddress;
			/*		
				var ab = {};
				ab.restName = restname;*/
					
				/*var orestname = new sap.ui.model.json.JSONModel();
				this.getView().setModel(orestname, "orestname");
				sap.ui.getCore().getModel("orestname").setData("/ab", ab);*/

				var a = [restname, restidd, restAddress];
				console.log(a);

				console.log(restidd);
				console.log(restname);
				console.log(restAddress);

				var oCdata2 = new sap.ui.model.json.JSONModel(a);
				sap.ui.getCore().setModel(oCdata2, "oCdata2");

				console.log(oCdata2);

				var oCustomer = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oCustomer, "oCustomer");
				var url = "/FoodApp/Food/Itemget/" + restidd;
				var oHeader = {
					"Content-Type": "application/json;charset=utf-8"
				};

				var aData = {};
				oCustomer.loadData(url, JSON.stringify(aData), true, "POST", false, false, oHeader);
				oCustomer.attachRequestCompleted(function (oEvent) {
					check = oEvent.getSource().getData();
					//	var check = oEvent.mParameters;
					console.log(check);
					sap.ui.getCore().setModel(oCustomer, "oCustomer");

					//	this.getView().setModel(oCustomer, "oItemdata");

					console.log(oCustomer);
					this.oRouter.navTo("Customerview3");
				}.bind(this));

				oCustomer.attachRequestFailed(function (oEvent) {

				});

				//	this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				//	
			}
			//	oncalling: function () {

		//	this.getView().setModel(oItemdata, "oItemdata");
		//				var aitemData = this.oCustomer;
		//	var oItemdata = new sap.ui.model.json.JSONModel(check);
		//	this.getView().setModel(oItemdata, "oItemdata");
		//			sap.ui.getCore()._yourData = check;
		//	this.getView().getModel("oItemdata").setProperty("/aitemData", aitemData);
		//				console.log(aitemData);
		//		}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.incture.cherrywork.foodApp.view.CustomerView2a
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.incture.cherrywork.foodApp.view.CustomerView2a
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.incture.cherrywork.foodApp.view.CustomerView2a
		 */
		//	onExit: function() {
		//
		//	}

	});

});