sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";

	var sum;
	var orderDetails;
	return Controller.extend("com.incture.cherrywork.foodApp.controller.Customerview3", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.incture.cherrywork.foodApp.view.Customerview3
		 */

		onInit: function () {

			var oModel = sap.ui.getCore().getModel("oCustomer");
			this.getView().setModel(oModel);

			var oModel2 = sap.ui.getCore().getModel("oCdata2");
			this.getView().setModel(oModel2);
			console.log(oModel2);
			var restn = oModel2.getData();
			var restNAME = restn[0];

			var oRestname = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oRestname, "oRestname");
			var RestName = restNAME;
			console.log(RestName);
			this.getView().getModel("oRestname").setProperty("/RestName", RestName);
			console.log(oRestname);

			var oModel1 = sap.ui.getCore().getModel("oCdata");
			this.getView().setModel(oModel1);
			console.log(oModel1);
			this.getView().setModel(oModel1);
			//	console.log(oModel1);

			//	var x = oModel.getSource().getBindingContext("oCustomer").getObject();
			//	console.log(x);
			var a = oModel.getData();
			console.log(a);

			var b = oModel1.getData();
			console.log(b);
			console.log(oModel1);
			var cName = b.name;
			var cEmail = b.email;
			var caddress = b.address;
			var cid = b.customerId;
			console.log(cName);
			console.log(cEmail);

			var c = oModel2.getData();
			var restname = c[0];
			var restid = c[1];
			var restAddress = c[2];

			var oIidata = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oIidata, "oIidata");

			var itemdatai = a;
			console.log(itemdatai);
			this.getView().getModel("oIidata").setProperty("/itemdatai", itemdatai);

			orderDetails = {};

			orderDetails.cname = cName;
			orderDetails.cId = cid;
			orderDetails.email = cEmail;
			orderDetails.restAddress = restAddress;
			orderDetails.restId = restid;
			orderDetails.restName = restname;

			/*	var aData = [{
					quantity: "q"
				}];
			Object.assign(itemdatai, {key3: "value3"});
				console.log(itemdatai);*/

			//	sap.ui.controller("com.incture.cherrywork.foodApp.controller.CustomerView2a").oncalling();

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(function (oEvent) {
				if (oEvent.getParameter("name") === "Customerview3") {
					//
				}
			});

			/*var q = 0;
			this.getView().setModel(new JsonModel(), "oDetails");
			var aData = [{
				quantity: q
			}];
			//	console.log(aData);
			this.getView().getModel("oDetails").setProperty("/aData", aData);*/
			//console.log(oIidata);
		},

		/*onIncrese: function (Event) {
			//	console.log("msg");
			//	var select = this.getView().byId("Quantity").getValue();
			//	console.log(select);
			//	if ()
			var oItem = Event.getSource().getBindingContext("oDetails").getObject();
			//	console.log(oItem);
			var incrse = oItem.quantity;
			incrse = incrse + 1;
			//	console.log(incrse);

			var aData = [{
				quantity: incrse
			}];

			this.getView().getModel("oDetails").setProperty("/aData", aData);

		},
		onDecrese: function (Event) {
			//	var a =	this.getView().getModel("oDetails").getData();
			var a = Event.getSource().getBindingContext("oDetails").getObject();
			var b = a.quantity;
			//	console.log(b);
			if (b > 0) {
				var oItem = Event.getSource().getBindingContext("oDetails").getObject();
				//	console.log(oItem);
				var incrse = oItem.quantity;
				incrse = incrse - 1;
				//	console.log(incrse);
				var aData = [{
					quantity: incrse
				}];
				this.getView().getModel("oDetails").setProperty("/aData", aData);
			}
		},*/

		onPlaceOrder: function (Event) {
			var cart = [];
			//	console.log(this.oIidata);
			//	var itemDetails = Event.getSource().getBindingContext("oIidata");
			var itemDetails = this.getView().getModel("oIidata").getData();
			console.log(itemDetails);
			var x = itemDetails.itemdatai.length;

			for (var i = 0; i < x; i++) {
				var y = itemDetails.itemdatai[i].quantity;
				console.log(y);
				if (y > 0) {
					cart.push(itemDetails.itemdatai[i]);
				}
			}
			console.log(cart);
			var oModel = new JSONModel({
				modelData: cart
			});
			this.getView().setModel(oModel);

			var items = "";
			for (var k = 0; k < cart.length; k++) {

				var abc = cart[k].itemName;
				items = items + " " + abc;
			}
			console.log(items);

			orderDetails.items = items;

			var totalprice = [];
			for (var j = 0; j < cart.length; j++) {
				var price = cart[j].itemPrice;
				var quantity = cart[j].quantity;
				var total = price * quantity;
				totalprice.push(total);
			}
			console.log(totalprice);

			sum = totalprice.reduce(add, 0);

			function add(a, b) {
				return a + b;
			}
			console.log(sum);

			var totalSum = {};
			totalSum.price = sum;

			console.log(totalSum);

			cart.unshift(totalSum);
			console.log(cart);

			orderDetails.totalPrice = sum;

		/*	var oItemPrice = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oItemPrice, "oItemPrice");
		//	var ItemPrice = totalSum;
			this.getView().getModel("oItemPrice").setProperty("/totalSum", totalSum);
			console.log(oItemPrice);*/
			/*var oModel12 = new JSONModel({
				modelData1: totalSum
			});
			this.getView().setModel(oModel12);
			console.log(oModel12);*/

			var FragmentName = "com.incture.cherrywork.foodApp.fragment.customerorder";
			var fragId = "customerorder";
			if (!this.DialogFragment) {
				this.DialogFragment = this.createFragment(fragId, FragmentName);
				this.getView().addDependent(this.DialogFragment);
			}
			this.DialogFragment.open();

			/*	var qantity = this.getView().byId("quantity").getValue();
				console.log(qantity);
				var price = this.getView().byId("itemPrice").getText();
				//		console.log(price);
				var total = price * qantity;
				console.log(total);*/

		},
		createFragment: function (sFragmentID, sFragmentName) {
			var oFragment = sap.ui.xmlfragment(sFragmentID, sFragmentName, this);
			return oFragment;
		},

		/*onChange: function (oEvent) {
			var itemDetails = oEvent.getSource().getBindingContext("oIidata").getObject();

			console.log(itemDetails);

			//	var qantity = this.getView().byId("quantity").getValue();
			//	var zx = oEvent.getParameter("name");
			//	console.log(zx);
			/*
						var b = [{
							quantity: a
						}];

						var x = oEvent.getParameter("value");
						b.push(x.quantity);
						console.log(x);
			//console.log(qantity);
		},*/

		onOrder: function () {
				var Address = sap.ui.core.Fragment.byId("customerorder", "DeliveryAddress").getValue();
				if (Address === "") {
					MessageToast.show("Address can not be empty");
					return false;
				}
				var Address1 = sap.ui.core.Fragment.byId("customerorder", "DeliveryAddress1").getValue();
				if (Address1 === "") {
					MessageToast.show("Landmark can not be empty");
					return false;
				}
				var deliveryAddress = Address + "  " + Address1;
				orderDetails.caddress = deliveryAddress;

				var oCustomerlogin = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oCustomerlogin, "oCustomerlogin");
				var url = "/FoodApp/Food/Orderpost";
				var oHeader = {
					"Content-Type": "application/json;charset=utf-8"
				};

				console.log(orderDetails);
				/*	aData.caddress =
					aData.cname =
					aData.cemail =
					aData.restAddress =
					aData.restId =
					aData.restName =
					aData.totalPrice =*/

				oCustomerlogin.loadData(url, JSON.stringify(orderDetails), true, "POST", false, false, oHeader);
				oCustomerlogin.attachRequestCompleted(function (oEvent) {

				}.bind(this));

				oCustomerlogin.attachRequestFailed(function (oEvent) {

				});

				this.oRouter.navTo("CustomerView2a");
			}
			/*	var qantity = this.getView().byId("quantity").getValue();
				console.log(qantity);
				var price = this.getView().byId("itemPrice").getText();
				console.log(price);

				var total = price * qantity;
				console.log(total);
				var oItem = Event.getSource().getBindingContext("oDetails").getObject();
				//	console.log(oItem);

				this.oRouter.navTo("CustomerView4");

			} * /
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.incture.cherrywork.foodApp.view.Customerview3
			 */
			//onBeforeRendering: function (oEvent) {

		//	}

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.incture.cherrywork.foodApp.view.Customerview3
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.incture.cherrywork.foodApp.view.Customerview3
		 */
		//	onExit: function() {
		//
		//	}

	});

});