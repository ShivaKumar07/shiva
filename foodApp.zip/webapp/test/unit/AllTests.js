sap.ui.define([
	"com/incture/cherrywork/foodApp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});